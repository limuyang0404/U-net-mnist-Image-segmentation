# coding=UTF-8
import numpy as np
from examples.seismic import Model, plot_velocity
from examples.seismic import TimeAxis
from examples.seismic import Receiver
from devito import TimeFunction
from devito import Eq, solve
from examples.seismic import RickerSource
from devito import Eq, solve
from devito import Operator
from examples.seismic import plot_shotrecord
from PIL import Image
import matplotlib.pyplot as plt
'''this function is made to get a Two-dimensional dimensions with mirrored edges'''
#NBVAL_IGNORE_OUTPUT

# Define a physical size
# shape = (2000, 1000)  # Number of grid point (nx, nz)
shape = (101, 101)  # Number of grid point (nx, nz)
spacing = (1., 1.)  # Grid spacing in m. The domain size is now 1km by 1km
# spacing = (10., 10.)  # Grid spacing in m. The domain size is now 1km by 1km
origin = (0., 0.)  # What is the location of the top left corner. This is necessary to define
# the absolute location of the source and receivers

# Define a velocity profile. The velocity is in km/s
img = plt.imread('1211.png')
img = img[:, :, 0:3]
v = np.empty((img.shape[0], img.shape[1]), dtype=np.float32)
print(img[-20:, -20:])
print(img.shape[0], img.shape[1], img.shape[2])
for i in range(img.shape[0]):
    for j in range(img.shape[1]):
        # if set(np.uint8(img[i, j, :]*255)).difference(set(np.array([222, 141, 78]))) == []:
        if (np.uint8(img[i, j, :]*255) - np.array([222, 141, 78])).any():
            v[i, j] = 4500
        # if set(np.uint8(img[i, j, :]*255)).difference(set(np.array([88, 56, 132]))) == []:
        elif (np.uint8(img[i, j, :]*255) - np.array([88, 56, 132])).any():
            v[i, j] = 5000
        else:
            v[i, j] = 4500
print(v)
plt.imshow(v)
plt.show()
v = np.moveaxis(v, 0, -1)
# v = np.empty(shape, dtype=np.float32)
# v[:, :51] = 1.5
# v[:, 51:] = 2.5

# With the velocity and model size defined, we can create the seismic model that
# encapsulates this properties. We also define the size of the absorbing layer as 10 grid points
model = Model(vp=v, origin=origin, shape=shape, spacing=spacing,
              space_order=2, nbl=10, bcs="damp")

plot_velocity(model)





t0 = 0.  # Simulation starts a t=0
tn = 2000.  # Simulation last 1 second (1000 ms)
dt = model.critical_dt  # Time step from model grid spacing

time_range = TimeAxis(start=t0, stop=tn, step=dt)

f0 = 0.005  # Source peak frequency is 10Hz (0.010 kHz)
src = RickerSource(name='src', grid=model.grid, f0=f0,
                   npoint=1, time_range=time_range)

print('model.domain_size info:', model.domain_size, type(model.domain_size))
print('src.coordinates_data info:', src.coordinates_data, type(src.coordinates_data), src.coordinates_data.shape)

# First, position source centrally in all dimensions, then set depth
src.coordinates.data[0, :] = np.array(model.domain_size) * .5
src.coordinates.data[0, -1] = 30  # Depth is 20m


print('src.coordinates_data info:', src.coordinates_data, type(src.coordinates_data), src.coordinates_data.shape)
# We can plot the time signature to see the wavelet
src.show()



# Create symbol for 101 receivers
rec = Receiver(name='rec', grid=model.grid, npoint=101, time_range=time_range)

# Prescribe even spacing for receivers along the x-axis
rec.coordinates.data[:, 0] = np.linspace(0, model.domain_size[0], num=101)
rec.coordinates.data[:, 1] = 10  # Depth is 20m   #receiver depth

# We can now show the source and receivers within our domain:
# Red dot: Source location
# Green dots: Receiver locations (every 4th point)
plot_velocity(model, source=src.coordinates.data,
              receiver=rec.coordinates.data[::10, :])#::10 10 point a receiver




# Define the wavefield with the size of the model and the time dimension
u = TimeFunction(name="u", grid=model.grid, time_order=2, space_order=2)

print('model.m:', model.m, type(model.m))


# We can now write the PDE
pde = model.m * u.dt2 - u.laplace + model.damp * u.dt

# The PDE representation is as on paper
print(pde)

stencil = Eq(u.forward, solve(pde, u.forward))
src_term = src.inject(field=u.forward, expr=src * dt**2 / model.m)

# Create interpolation expression for receivers
rec_term = rec.interpolate(expr=u.forward)
#NBVAL_IGNORE_OUTPUT

op = Operator([stencil] + src_term + rec_term, subs=model.spacing_map)
op(time=time_range.num-1, dt=model.critical_dt)

plot_shotrecord(rec.data, model, t0, tn)

assert np.isclose(np.linalg.norm(rec.data), 370, rtol=1)











