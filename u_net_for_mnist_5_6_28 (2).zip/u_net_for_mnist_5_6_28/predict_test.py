# coding=UTF-8
import numpy as np
from PIL import Image
import matplotlib.pyplot as plt
from os import listdir
import random
from os.path import isfile, join, getsize
from label_img_into_label import label_img_into_label, get_data, get_single_data
from texture_net import TextureNet
import torch
from torch import nn
import math
'''this function is made to get a Two-dimensional dimensions with mirrored edges'''
def predict_area(data_img):#newwork input img
    network = TextureNet(n_classes=11)
    cross_entropy = nn.CrossEntropyLoss()  # Softmax function is included
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    print(torch.cuda.device_count())
    # Transfer model to gpu
    if torch.cuda.device_count() > 1:
        network = nn.DataParallel(network)
    network.to(device)
    # network.load_state_dict = (checkpoint)    #pytorch调用先前的模型参数
    network.eval()
    optimizer = torch.optim.Adam(network.parameters(), lr=0.003)  # Adam method
    # optimizer.load_state_dict(torch.load(join('F3','optimizer.pth')))
    checkpoint = {'model': network.state_dict(), 'optimizer': optimizer.state_dict()}
    model_path = 'saved_model.pt'
    optimizer_path = 'optimizer.pth'
    network.module.load_state_dict(torch.load(model_path))
    # img_path = "imgs/mnist_train_jpg_6000_mirror"
    # img_path = "imgs/mnist_test_jpg_1000_mirror"
    img_path = "imgs"
    label_img_path = "imgs/mnist_train_jpg_6000_classify_mirror"
    for state in optimizer.state.values():
        for k, v in state.items():
            if torch.is_tensor(v):
                state[k] = v.cuda()
    optimizer.load_state_dict(torch.load(optimizer_path))
    data = data_img.to(device)
    network.eval()
    output = network(data)
    net_output = nn.Softmax(dim=1)(output)
    net_output = torch.squeeze(net_output)
    net_output = net_output.cpu()
    array = (net_output).detach().numpy()
    tensor_size0, tensor_size1, tensor_size2 = net_output.size(0), net_output.size(1), net_output.size(2)
    predict = np.zeros((tensor_size1, tensor_size2))
    for i in range(tensor_size1):
        for j in range(tensor_size2):
            value = 0
            for k in range(tensor_size0):
                value += array[k, i, j] * k  # like a vote process
            predict[i, j] = value
    return predict
def predict(net_output):
    net_output = nn.Softmax(dim=1)(net_output)
    net_output = torch.squeeze(net_output)
    net_output = net_output.cpu()
    array = (net_output).detach().numpy()
    tensor_size0, tensor_size1, tensor_size2 = net_output.size(0), net_output.size(1), net_output.size(2)
    predict = np.zeros((tensor_size1, tensor_size2))
    for i in range(tensor_size1):
        for j in range(tensor_size2):
            value = 0
            for k in range(tensor_size0):
                # print(i, j, k, array[k, i, j])
                value += array[k, i, j]*k       #like a vote process
            predict[i, j] = value
    predict = predict[14:42, 14:42]
    plt.imshow(predict)
    plt.show()
    return

def feature_1_view(feature_1):
    feature_1 = torch.squeeze(feature_1)
    feature_1 = feature_1.cpu()
    array = feature_1.detach().numpy()
    b = array.reshape(feature_1.size(0)*feature_1.size(1)*feature_1.size(2),).tolist()
    img_out = np.zeros((254, 518, 3))
    t = 0
    for i in range(4):
        for j in range(8):
            img_out[i*66:i*66+56, j*66:j*66 + 56, 0] = np.uint8(array[t, :, :]/max(b)*255)
            img_out[i*66:i*66+56, j*66:j*66 + 56, 1] = np.uint8(array[t, :, :]/max(b)*255)
            img_out[i*66:i*66+56, j*66:j*66 + 56, 2] = np.uint8(array[t, :, :]/max(b)*255)
            t += 1
    img_out2 = np.uint8(img_out*2)
    plt.imshow(img_out2)
    plt.savefig('feature_1_2.png')
    plt.show()
    return

def feature_view(feature):
    feature = (torch.squeeze(feature)).cpu()
    array = np.moveaxis(feature.detach().numpy(), 0, -1)
    print(feature.size(0), feature.size(1), feature.size(2))
    img_shape = ()
    if feature.size(0)**0.5 == math.floor(feature.size(0)**0.5):
        img_shape = (math.floor(feature.size(0)**0.5)*feature.size(1)+(math.floor(feature.size(0)**0.5)-1)*math.ceil(feature.size(1)/4), math.floor(feature.size(0)**0.5)*feature.size(1)+(math.floor(feature.size(0)**0.5)-1)*math.ceil(feature.size(1)/4), 3)
    elif feature.size(0)**0.5 != math.floor(feature.size(0)**0.5):
        img_shape = ((math.floor((feature.size(0)/2)**0.5))*feature.size(1)+(math.floor((feature.size(0)/2)**0.5)-1)*math.ceil(feature.size(1)/4), 2*(math.floor((feature.size(0)/2)**0.5))*feature.size(1)+(2*math.floor((feature.size(0)/2)**0.5)-1)*math.ceil(feature.size(1)/4), 3)
    print(img_shape)
    arraylist = array.reshape(feature.size(0)*feature.size(1)*feature.size(2),).tolist()
    img_out = np.ones(img_shape)*255
    img_counter = 0
    axis1 = math.floor((img_shape[0]+math.ceil(feature.size(1)/4))/(feature.size(1)+math.ceil(feature.size(1)/4)))
    print(type(axis1))
    axis2 = math.floor((img_shape[1]+math.ceil(feature.size(1)/4))/(feature.size(1)+math.ceil(feature.size(1)/4)))
    for i in range(axis1):
        for j in range(axis2):
            print(i*(feature.size(1)+math.ceil(feature.size(1)/4))+feature.size(1), j*(feature.size(1)+math.ceil(feature.size(1)/4))+feature.size(1), j)
            img_out[i*(feature.size(1)+math.ceil(feature.size(1)/4)):i*(feature.size(1)+math.ceil(feature.size(1)/4))+feature.size(1), j*(feature.size(1)+math.ceil(feature.size(1)/4)):j*(feature.size(1)+math.ceil(feature.size(1)/4))+feature.size(1), 0] = array[:, :, img_counter]/max(arraylist)*255
            img_out[i*(feature.size(1)+math.ceil(feature.size(1)/4)):i*(feature.size(1)+math.ceil(feature.size(1)/4))+feature.size(1), j*(feature.size(1)+math.ceil(feature.size(1)/4)):j*(feature.size(1)+math.ceil(feature.size(1)/4))+feature.size(1), 1] = array[:, :, img_counter]/max(arraylist)*255
            img_out[i*(feature.size(1)+math.ceil(feature.size(1)/4)):i*(feature.size(1)+math.ceil(feature.size(1)/4))+feature.size(1), j*(feature.size(1)+math.ceil(feature.size(1)/4)):j*(feature.size(1)+math.ceil(feature.size(1)/4))+feature.size(1), 2] = array[:, :, img_counter]/max(arraylist)*255
            img_counter += 1
    feature_name = ''
    for key in local_variable:
        if (local_variable[key] - feature).any():
            feature_name = key

    img_out = np.int16(img_out * 4)
    plt.imshow(img_out)
    plt.savefig(feature_name + '.png')
    plt.show()
    return

# i*(feature.size(1)+math.ceil(feature.size(1)/4)):i*(feature.size(1)+math.ceil(feature.size(1)/4))+feature.size(1), j*(feature.size(1)+math.ceil(feature.size(1)/4)):i*(feature.size(1)+math.ceil(feature.size(1)/4))+feature.size(1), 0

def feature_2_view(feature_2):
    feature_2 = torch.squeeze(feature_2)
    feature_2 = feature_2.cpu()
    array = feature_2.detach().numpy()
    print(array.shape)
    array = np.moveaxis(array, 0, -1)
    print(array.shape)
    b = array.reshape(feature_2.size(0)*feature_2.size(1)*feature_2.size(2),).tolist()
    img_out = np.ones((294, 294, 3))*255
    t = 0
    for i in range(8):
        for j in range(8):
            img_out[i*38:i*38+28, j*38:j*38 + 28, 0] = array[:, :, t]/max(b)*255
            img_out[i*38:i*38+28, j*38:j*38 + 28, 1] = array[:, :, t]/max(b)*255
            img_out[i*38:i*38+28, j*38:j*38 + 28, 2] = array[:, :, t]/max(b)*255
            t += 1
    img_out2 = np.int16(img_out*2)
    plt.imshow(img_out2)
    plt.savefig('feature_2_22.png')
    plt.show()
    return

def feature_3_view(feature_3):
    feature_3 = torch.squeeze(feature_3)
    feature_3 = feature_3.cpu()
    array = feature_3.detach().numpy()
    b = array.reshape(feature_3.size(0)*feature_3.size(1)*feature_3.size(2),).tolist()
    img_out = np.zeros((294, 294, 3))
    t = 0
    for i in range(8):
        for j in range(8):
            img_out[i*38:i*38+28, j*38:j*38 + 28, 0] = array[t, :, :]/max(b)*255
            img_out[i*38:i*38+28, j*38:j*38 + 28, 1] = array[t, :, :]/max(b)*255
            img_out[i*38:i*38+28, j*38:j*38 + 28, 2] = array[t, :, :]/max(b)*255
            t += 1
    img_out = np.int8(img_out*2)
    plt.imshow(img_out)
    plt.savefig('feature_2_2.png')
    plt.show()
    return

def feature_save(feature):
    # Save the feature map to the preset path
    feature_name = ''

    for key in local_variable:
        if local_variable[key] is feature:
            feature_name = key
    feature = (torch.squeeze(feature)).cpu()
    array = feature.detach().numpy()
    img_shape = array.shape
    for i in range(img_shape[0]):
        img_out = np.int16(array[i, :, :])
        im = Image.fromarray(np.uint8(img_out*300))
        im = im.convert('L')
        im.save(r'feature_map/layer' + feature_name[-1] + "/" +str(i+1) + '.png')
        # plt.imshow(img_out)
        # plt.savefig(r'feature_map/layer' + feature_name[-1] + "/" +str(i) + '.png')
        print('the', i, 'the feature have been saved')
    return
#
# network = TextureNet(n_classes=11)
# cross_entropy = nn.CrossEntropyLoss() #Softmax function is included
# device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
# print(torch.cuda.device_count())
# #Transfer model to gpu
# if torch.cuda.device_count()>1:
#     network = nn.DataParallel(network)
# network.to(device)
# # network.load_state_dict = (checkpoint)    #pytorch调用先前的模型参数
# network.eval()
# optimizer = torch.optim.Adam(network.parameters(), lr=0.003)#Adam method
# # optimizer.load_state_dict(torch.load(join('F3','optimizer.pth')))
# checkpoint = {'model':network.state_dict(),'optimizer':optimizer.state_dict()}
# model_path = 'saved_model.pt'
# optimizer_path = 'optimizer.pth'
# network.module.load_state_dict(torch.load(model_path))
# # img_path = "imgs/mnist_train_jpg_6000_mirror"
# # img_path = "imgs/mnist_test_jpg_1000_mirror"
# img_path = "imgs"
# label_img_path = "imgs/mnist_train_jpg_6000_classify_mirror"
#
#
# for state in optimizer.state.values():
#     for k, v in state.items():
#         if torch.is_tensor(v):
#             state[k] = v.cuda()
# optimizer.load_state_dict(torch.load(optimizer_path))
#
# data = get_single_data(join(img_path, 'haha.png'))
# # label = label_img_into_label(join(label_img_path, '9_436_4350.png'))
# data = data.to(device)
# # label = label.to(device)
# network.eval()
# output = network(data)
# predict(output)
if __name__ == '__main__':
    network = TextureNet(n_classes=11)
    print(type(network), dir(network))
    cross_entropy = nn.CrossEntropyLoss()  # Softmax function is included
    # device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    # print(torch.cuda.device_count())
    # Transfer model to gpu
    # if torch.cuda.device_count() > 1:
    #     network = nn.DataParallel(network)
    # network.to(device)
    # network.load_state_dict = (checkpoint)    #pytorch调用先前的模型参数
    network.eval()
    # optimizer = torch.optim.Adam(network.parameters(), lr=0.003)  # Adam method
    # optimizer.load_state_dict(torch.load(join('F3','optimizer.pth')))
    # checkpoint = {'model': network.state_dict(), 'optimizer': optimizer.state_dict()}
    model_path = 'saved_model.pt'
    optimizer_path = 'optimizer.pth'
    network.load_state_dict(torch.load(model_path))
    # img_path = "imgs/mnist_train_jpg_6000_mirror"
    img_path = "imgs/mnist_test_jpg_1000_mirror"
    # img_path = "imgs"
    label_img_path = "imgs/mnist_train_jpg_6000_classify_mirror"
    # for state in optimizer.state.values():
    #     for k, v in state.items():
    #         if torch.is_tensor(v):
    #             state[k] = v.cuda()
    # optimizer.load_state_dict(torch.load(optimizer_path))
    data = get_single_data(join(img_path, '8_8_179.png'))
    # label = label_img_into_label(join(label_img_path, '9_436_4350.png'))
    # data = data.to(device)
    print(data.size())
    # label = label.to(device)
    network.eval()
    output, feature1, feature2, feature3, feature4 = network.classify(data)
    print(type(feature1), feature1.size())
    print(type(feature2), feature2.size())
    print(type(feature3), feature3.size())
    print(type(feature4), feature4.size())
    predict(output)
    # feature_1_view(feature1)
    # feature_2_view(feature2)
    print('*****************************************************************')
    print('*****************************************************************')
    print('*****************************************************************')
    local_variable = locals()
    print(type(local_variable))
    # feature_view(feature1)
    # print('$'*50)
    # feature_view(feature2)
    feature_save(feature1)
    feature_save(feature2)
    feature_save(feature3)

